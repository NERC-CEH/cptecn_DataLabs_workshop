#' Identify changepoints in mixed sampling rate sequences
#'
#' @description
#' Calculates the optimal positioning and (potentially) number of changepoints for mixed sampling rate sequences.
#'
#' @param data dataframe, Or a list of dataframes. If data is a list, each list entry provides sequence data. If data is a dataframe it contains data for all sequences. There must be a column specified with key_column that is used to identify data for sequence. All dataframes must have a column of type "Date" specifying the time index and a "numeric" column specifying the sequence values, see "changepoint.msr::liData" and "changepoint.msr::dfData" for list and dataframes examples respectively.
#' @param penalty vector. Each element corresponds to a sequence. Elements can be any combination of "aic" or "bic" or a numeric value. A numeric value is a user defined penalty.
#' @param method Choice of "AMOC" or "OP".
#' @param test.stat vector. Each element corresponds to a sequence. Elements can be any combination of "normal_meanvar" or "poisson_meanvar".
#' @param minseglens vector or NULL. If minseglens is null the minimum segment lengths are based on test.stat elements. If minseglens is a vector each element corresponds to a sequence and must be of "integer" type.
#' @param key_value character. Column name giving the values.
#' @param key_index A character. Column name giving the index.
#' @param key_column character or NULL. Used only if data is data.frame. Column name of the data that identifies each sequence.
#' @param keys vector or NULL. Used only if data is data.frame. If keys is NULL all sequences will be used. Otherwise, only those sequences specified in keys.
#'
#' @return If 'method="AMOC"' then an object of S4 class "cpt.msr.test" is returned. Otherwise, an object of S4 class "cpt.msr".
#'
#' @slot time_called Time called.
#' @slot time_complete Time complete.
#' @slot data "tibble::tibble()". Data that was analysed.
#' @slot params "tibble::tibble()". Options provided in call to "cpt.msr()".
#' @slot msr.cpts vector. Optimal mixed sampling rate changepoint locations for the penalty supplied.
#' @slot cpts "tibble::tibble()". Optimal changepoint locations derived from msr.cpts.
#' @slot window vector. Observation window for the data.
#' @slot lastchangelik dataframe. Cost (-2*loglikelihood) of the optimal segmentation up to that observation.
#' @slot unique_index vector. Ordered union of observed time indices.
#' @slot msr.cpt Date. Most likely msr changepoint location.
#' @slot cpt "tibble::tibble()". Most likely changepoint locations derived from msr.cpts.
#' @slot lik_null -2*log-likelihood under the null hypothesis.
#' @slot lik_alt -2*log-likelihood under the alternative hypothesis.
#' @slot lrts Likelihood ratio test statistic.
#' @slot test_signif Logical. Does lrts exceed exceed "sum(params$penalty)"?
#'
#' @examples
#' cpt.msr(dfData, rep("bic", 3), "OP",
#'     rep("normal_meanvar", 3), NULL, "value", "index", "iid",
#'     NULL)
#'
#' @importFrom dplyr "%>%"
#'
#' @export
#'
cpt.msr <- function(data,
                   penalty,
                   method = "OP",
                   test.stat,
                   minseglens = NULL,
                   key_value = "VALUE",
                   key_index = "DATETIME",
                   key_column = NULL,
                   keys = NULL)
{
    ## checks
    formatted_data <- check_Args(
        data,
        test.stat,
        penalty,
        minseglens,
        key_value,
        key_index,
        keys,
        key_column
    )

    ## data preparation
    P <- length(formatted_data)

    ## parameter table
    params <- params_tbl(
        formatted_data,
        test.stat,
        keys,
        penalty,
        minseglens
    )

    ## strip index for c
    allindex <- do.call(
        c,
        lapply(
            formatted_data,
            function(x){return(dplyr::pull(x,'index'))}
        )
    )

    ## strip values for c
    allvalue <- do.call(
        c,
        lapply(
            formatted_data,
            function(x){return(dplyr::pull(x, 'value'))}
        )
    )

    ## call c routine
    c.WrapperOut <- c.wrapper(
        as.integer(allindex),
        allvalue,
        params,
        method
    )

    if( method == "OP" )
    {
        ## changepoints
        out <- methods::new(
            "cpt.msr",
            time_called = c.WrapperOut$time_called,
            time_complete = c.WrapperOut$time_complete,
            data = do.call(rbind, formatted_data),
            params = params[,
                            c(
                                'id',
                                'key',
                                'T',
                                'cost',
                                'minseglen',
                                'penname',
                                'penalty'
                            )
                            ],
            msr.cpts = tibble::tibble(
                                   loc = c.WrapperOut$msr.cpts,
                                   m = 1:length(c.WrapperOut$msr.cpts)
                               ),
            cpts = map_changepoints(
                c.WrapperOut$msr.cpts,
                formatted_data
            ),
            window = c(
                c.WrapperOut$unique_index[1],
                c.WrapperOut$unique_index[c.WrapperOut$nunique]
            ),
            lastchangelik =
                tibble::tibble(
                            index = c.WrapperOut$unique_index,
                            '-2*loglik' = c.WrapperOut$lastchangelik
                        )
            )
    } else if(method == "AMOC")
    {
        out <- methods::new(
            "cpt.msr.test",
            time_called = c.WrapperOut$time_called,
            time_complete = c.WrapperOut$time_complete,
            data = do.call(rbind, formatted_data),
            unique_index = c.WrapperOut$unique_index,
            params = params[,
                            c(
                                'id',
                                'key',
                                'T',
                                'cost',
                                'minseglen',
                                'penname',
                                'penalty')
                            ],
            msr.cpt = tibble::tibble(
                                  loc = c.WrapperOut$msr.cpts[1],
                                  m = 1
                               ),
            cpt = map_changepoints(
                c.WrapperOut$msr.cpts[1],
                formatted_data
            ),
            window = c(
                c.WrapperOut$unique_index[1],
                c.WrapperOut$unique_index[c.WrapperOut$nunique]
            ),
            lik_null = c.WrapperOut$lastchangelik[1],
            lik_alt = c.WrapperOut$lastchangelik[2],
            lrts = c.WrapperOut$lastchangelik[3],
            test_signif = c.WrapperOut$n.msr.cpts == 2
        )
    }else
    {
        stop("only AMOC or OP method supported")
    }

    return(out)
}

#' @useDynLib changepoint.msr
c.wrapper <- function(stacked_index,
                      stacked_values,
                      params,
                      method)

{
    P <- nrow(params)
    minseglen <- params$minseglen
    beta <- params$penalty
    costname <- params$cost

    ## some inputs to C
    T <- params$T
    sumT <- sum(T)

    ## variables for C to modify
    nunique <- -1
    unique_index <- array(-1, dim=sumT)
    n.msr.cpts <- -1
    msr.cpts <- array(0, dim=sumT)
    lastchangelik <- array(-1, dim=sumT+1)

    ## set storage mode of arrays
    storage.mode(T) = "integer"

    storage.mode(stacked_index) = "integer"
    storage.mode(stacked_values) = "double"
    storage.mode(minseglen) = "integer"
    storage.mode(beta) = "double"
    storage.mode(costname) = "character"
    ## costname

    storage.mode(unique_index) = "integer"
    storage.mode(msr.cpts) = "integer"
    storage.mode(lastchangelik) = "double"

    ## function to call C routine
    time_called <- Sys.time()
    cCall.output <- .C(
        "Call",
        as.integer( P ),        # 1. P
        T,                      # 2. T
        as.integer( sumT ),     # 3. sumT
        as.integer( max(T) ),   # 4. Tmax

        stacked_index,          # 5. index
        stacked_values,         # 6. values

        minseglen,              # 7. minseglen
        beta,                   # 8. beta
        costname,               # 9. costname

        as.integer(nunique),    # 10. in_nunique
        unique_index,           # 11. in_unique_index
        as.integer(n.msr.cpts), # 12. in_ncpts
        msr.cpts,               # 13. in_cpts
        lastchangelik,          # 14. in_lastchangelik
        as.character(method),   # 15. method
        PACKAGE = "changepoint.msr"
    )
    time_complete <- Sys.time()

    ## extract output
    nunique <- cCall.output[[10]]
    ui <- as.Date(cCall.output[[11]][1:nunique], origin="1970-01-01")
    n.msr.cpts <- cCall.output[[12]]
    msr.cpts <- ui[sort(cCall.output[[13]][1:n.msr.cpts])]
    lastchangelik <- cCall.output[[14]][1:nunique]

    ## return
    return(
        list(
            nunique = nunique,
            unique_index = ui,
            n.msr.cpts = n.msr.cpts,
            msr.cpts = msr.cpts,
            lastchangelik = lastchangelik,
            time_called = time_called,
            time_complete = time_complete
        )
    )
}
