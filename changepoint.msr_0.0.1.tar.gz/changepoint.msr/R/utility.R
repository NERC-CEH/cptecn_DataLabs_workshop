check_Args <- function(data,
                       costs,
                       penalties,
                       minseglens,
                       key_value,
                       key_index,
                       keys,
                       key_column)
{
    ## costs check
    if( !all(costs %in% c("normal_meanvar", "poisson_meanvar")) )
    {
        stop("only the following cost supported: meanvar_normal, meanvar_poisson")
    }

    ## penalties check
    if( !is.numeric(penalties) )
    {
        if( !all(penalties %in% c("aic", "bic")) )
        {
            stop("only the following penalties supported: meanvar_normal, meanvar_poisson")
        }
    }

    ##  formatted data that will be returned
    out <- list()

    if( "list" %in% class(data) )
    {
        if(!is.null(keys))
        {
            warning("keys supplied but not used as data is a list")
        }

                                        # number of sequences
        P <- length(data)

        for(p in 1:P)
        {
                                        # extract data and sort by index
            out[[p]] <-
                tibble::tibble(
                            index = dplyr::pull(data[[p]], key_index),
                            value = dplyr::pull(data[[p]], key_value),
                            id = p
                        ) %>% dplyr::arrange_at('index')
        }
    } else if( "data.frame" %in% class(data) )
    {
        if( is.null(keys) )
        {
            keys <- sort(unique(dplyr::pull(data, key_column)))
        }

        P <- length(keys)

        for(p in 1:P)
        {
            ## extract sequence data from dataframe
            logic <- data[,key_column] == keys[p]

            ## sort by index
            out[[p]] <-
                tibble::tibble(
                            index = dplyr::pull(data[logic,], key_index),
                            value = dplyr::pull(data[logic,], key_value),
                            id = p
                        ) %>% dplyr::arrange_at('index')
        }
    } else
    {
        stop("data must be list or data.frame")
    }

    return(out)
}

#' determine changepoint from msr changepoints
#'
#' @param msr.cpts vector. MSR changepoints
#' @param data list. Formatted data
#'
#' @export
map_changepoints <- function(msr.cpts, data)
{
    P <- length(data)
    out <- list()

    tmp_out <- msr.cpts
    for( p in 1:P )
    {
        M <- 0
        for( cpt in msr.cpts )
        {
            tmp_index <- dplyr::pull(data[[p]], "index")
            logic <- tmp_index <= cpt

            if( sum(logic) > 0)
            {
                M <- M+1
                tmp_out[M] <- max(tmp_index[logic])
            }
        }

        if(M > 0)
        {
            out[[p]] <- sort(unique(tmp_out[1:M]))
        }else
        {
            out[[p]] <- NA#NULL
        }
    }

    return(
        tibble::tibble(
                    loc = do.call(c, out),
                    id = do.call(
                        c,
                        mapply(
                            rep,
                            as.list(1:P),
                            lapply(out, length), SIMPLIFY=FALSE
                        )
                    ),
                    m = do.call(c, lapply(out, function(x){return(1:length(x))}))
                )
    )
    return(out)
}


params_tbl <- function(data, costs, keys, penalties, minseglens)
{
    P <- length(data)
    if( is.null(keys) )
    {
        keys <- 1:P
    }

    ## number of parameters for cost
    npars <- c("normal_meanvar" = 3, "poisson_meanvar" = 2)

    ## minimum segment length for cost
    msl <- c("normal_meanvar" = 2, "poisson_meanvar" = 1)

    ## initialise table
    params <- tibble::tibble(
                          T = do.call(c, lapply(data, nrow)),
                          cost = costs,
                          k = npars[costs],
                          logT = log(T),
                          key = keys,
                          id = 1:P
                      )

    if( !is.numeric(penalties) )
    {
        params[,'penalty'] <- 2*params$k*(penalties == "aic") +
            params$k*params$logT*(penalties == "bic")
        params[,'penname'] <- penalties
    }else
    {
        params[,'penname'] <- rep("user_defined", P)
        params[,'penalty'] <- penalties
    }
    if( is.null(minseglens) )
    {
        params[,'minseglen'] <- msl[costs]
    }else
    {
        params[,'minseglen'] <- minseglens
    }

    return( params )
}
