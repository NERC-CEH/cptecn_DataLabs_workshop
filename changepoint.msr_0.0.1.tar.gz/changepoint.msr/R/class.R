#' An S4 class for cpt.msr output when 'method="OP"'
#'
#' @slot time_called Time called.
#' @slot time_complete Time complete.
#' @slot data "tibble::tibble()". Data that was analysed.
#' @slot params "tibble::tibble()". Options provided in call to "cpt.msr()".
#' @slot msr.cpts vector. Optimal mixed sampling rate changepoint locations for the penalty supplied.
#' @slot cpts "tibble::tibble()". Optimal changepoint locations derived from msr.cpts.
#' @slot window vector. Observation window for the data.
#' @slot lastchangelik dataframe. Cost (-2*loglikelihood) of the optimal segmentation up to that observation.
#'
#' @export
setClass(
    "cpt.msr",
    slots = list(
        time_called = "POSIXt",
        time_complete = "POSIXt",
        data = "data.frame",
        params = "data.frame",
        msr.cpts = "data.frame",
        cpts = "data.frame",
        window = "Date",
        lastchangelik = "data.frame"
    )
)

#' An S4 class for cpt.msr when 'method="AMOC"'
#'
#' @slot time_called Time called.
#' @slot time_complete Time complete.
#' @slot data "tibble::tibble()". Data that was analysed.
#' @slot unique_index vector. Ordered union of observed time indices.
#' @slot params "tibble::tibble()". Options provided in call to "cpt.msr()".
#' @slot msr.cpt Date. Most likely msr changepoint location.
#' @slot cpt "tibble::tibble()". Most likely changepoint locations derived from msr.cpts.
#' @slot window vector. Observation window for the data.
#' @slot lik_null -2*log-likelihood under the null hypothesis.
#' @slot lik_alt -2*log-likelihood under the alternative hypothesis.
#' @slot lrts Likelihood ratio test statistic.
#' @slot test_signif Logical. Does lrts exceed exceed "sum(params$penalty)"?
#'
#' @export
setClass(
    "cpt.msr.test",
    slots = list(
        time_called = "POSIXt",
        time_complete = "POSIXt",
        data = "data.frame",
        unique_index = "Date",
        params = "data.frame",
        msr.cpt = "data.frame",
        cpt = "data.frame",
        window = "Date",
        lik_null = "numeric",
        lik_alt = "numeric",
        lrts = "numeric",
        test_signif = "logical"
    )
)
