#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "cost.h"
#include "utility.h"

void get_cpts(int n_unique,
	      int* in_cpts,
	      int* in_ncpts,
	      int lastchange[n_unique+1])
/*
  get changepoints
*/
{
  int prevchange = n_unique;
  *(in_cpts+0) = prevchange;
  *(in_ncpts) = 1;

  for( int i=0; i<n_unique-1; i++ )
    {
      prevchange=lastchange[prevchange];

      if( prevchange == 0 )
	{
	  break;
	}
      *(in_cpts+i+1) = prevchange;
      *(in_ncpts) += 1;
    }
}

void OP_MF(int N,
	   int sumT,
	   int minseglen[N],
	   double beta[N],
	   double sumbeta,
	   int n_unique_indices,
	   int counter[N][sumT+1],
	   double sumstat[N][3][sumT+1],
	   double (*cost_function_vla[N])(),
	   int lastchange[n_unique_indices+1],
	   double lastchangelik[n_unique_indices+1])
/*
  multi-frequency optimal partitioning

  N:                 number of data sequences
  sumT:              total number of observations
  minseglen:         array of minimum segment lengths
  beta:              array of penalties
  sumbeta:           sum of penalty array
  n_unique_indices:  number of unique indices
  counter:           array to store counts (to update)
  sumstat:           array to store summary statistics (to update)
  cost_function_vla: variable length array of functions returning
  doubles

  lastchange: array of last changepoints (to update)
  lastchangelik: array of last changepoint cost (to update)
*/
{
  lastchangelik[0] = -sumbeta;

  int checklist[n_unique_indices+1];
  initialize_int0(n_unique_indices+1, checklist);

  int nchecklist = 1;

  // initilasation
  int break_init = 0;
  int active = 0;
  int count = -1;

  int n=0;
  int t=-1;

  for(t=1; t<n_unique_indices+1; t++)
    {
      for(n=0; n<N; n++)
	{
	  count = counter[n][t];

	  if(count == 2*minseglen[n])
	    {
	      break_init = 1;
	      break;
	    }
	  if(count >= minseglen[n])
	    {
	      active=1;
	      lastchangelik[t] += cost_function_vla[n](N,
						       sumT+1,
						       sumstat,
						       n,
						       1,
						       t,
						       count);
	    } else
	    {
	      /* lastchangelik[t] += beta[n]; */
	      lastchangelik[t] += 0;
	    }
	}

      if( break_init == 1 )
	{
	  lastchangelik[t] = 0;
	  break;
	}
      if( active == 1 )
	{
	  checklist[nchecklist] = t;
	  nchecklist += 1;
	}else
	{
	  lastchangelik[t] = 0;
	}
      lastchange[t] = 0;
    }

  // now to run the big loop
  double propose[n_unique_indices+1];
  initialize_double0(n_unique_indices+1, propose);

  int i_checklist = 0;
  int ncheck = 0;
  int id_cpt = -1;

  for( int i=t; i<n_unique_indices+1; i++ )
    {
      ncheck = 0;

      for( i_checklist=0; i_checklist<nchecklist; i_checklist++ )
	{
	  active = 0;

	  for( n=0; n<N; n++ )
	    {
	      count = counter[n][i] - counter[n][checklist[i_checklist]];

	      if( count >= minseglen[n] )
		{
		  active = 1;

		  propose[i_checklist] +=
		    cost_function_vla[n](N,
					 sumT+1,
					 sumstat,
					 n,
					 checklist[i_checklist]+1,
					 i,
					 count);
		}else
		{
		  /* propose[i_checklist] += beta[n]; */
		  propose[i_checklist] += 0;
		}
	    }

	  if( active == 1 )
	    {
	      propose[i_checklist] += lastchangelik[checklist[i_checklist]] + sumbeta;

	      ncheck += 1;
	    }else
	    {
	      break;
	    }
	}

      id_cpt = argmin_double(ncheck, propose);

      lastchange[i] = checklist[id_cpt];

      lastchangelik[i] = propose[id_cpt];

      checklist[nchecklist] = i;
      nchecklist += 1;

      initialize_double0(ncheck+1, propose); // +1 in case beta[n] added
    }
}

void Sumstat_Count(int N,
		   int maxT,
		   int sumT,
		   int T[N],
		   int index[N][maxT],
		   double values[N][maxT],
		   int* n_unique_indices,
		   int unique_indices[sumT],
		   int counter[N][sumT+1],
		   double sumstat[N][3][sumT+1])
/*
  calculate summary statistics and counter arrays

  N:                number of data sequences
  maxT:             maximum number of observations
  sumT:             total number of observations
  T[N]:             each sequence number of observations
  index:            data sequence indices
  values:           data sequence values
  n_unique_indices: number of unique indices (to update)
  unique_indices:   unique indices (to update)
  counter:          array to store counts (to update)
  sumstat:          array to store summary statistics (to update)
*/
{
  int active = -1;
  int track[N]; initialize_int0(N, track);
  int exhausted[N]; initialize_int0(N, exhausted);
  int prop_max[N]; for(int n=0; n<N; n++){ prop_max[n] = index[n][ T[n]-1 ]; }
  int max_index = max_int(N,prop_max); // need to be larger than largest for counter
  int propose[N];

  for( int n=0; n<N; n++ )
    {
      propose[n] = index[n][track[n]];
      counter[n][0] = 0;

      sumstat[n][0][0] = 0;
      sumstat[n][1][0] = 0;
      sumstat[n][2][0] = 0;
    }

  for(int i=0; i<sumT; i++)
    {
      active = argmin_int(N,propose);

      unique_indices[i] = propose[active];
      ++*n_unique_indices;

      for(int n=0; n<N; n++)
  	{
  	  if( propose[n] == unique_indices[i] )
  	    {
  	      counter[n][i+1] = 1;
  	      sumstat[n][0][i+1] = values[n][ track[n] ];
  	      track[n]++;
  	    } else
  	    {
  	      counter[n][i+1] = 0;
  	      sumstat[n][0][i+1] = 0;
  	    }
  	  if( track[n] == T[n] )
  	    {
  	      exhausted[n] = 1;
  	      propose[n] = max_index+1; /*needs to be slighlty larger than largest\*/
		} else
  	    {
  	      propose[n] = index[n][ track[n] ];
  	    }
  	  counter[n][i+1] = counter[n][i] + counter[n][i+1];
  	  sumstat[n][1][i+1] = sumstat[n][1][i] + sumstat[n][0][i+1];
  	  sumstat[n][2][i+1] = sumstat[n][2][i] + sumstat[n][0][i+1]*sumstat[n][0][i+1];
  	}

      if( sum_int(N,exhausted) == N )
  	{
  	  // add largest index
  	  unique_indices[i] = max_index;
  	  ++*n_unique_indices;
  	  break;
  	}
    }
}

void AMOC(int P,
	  int sumT,
	  int minseglen[P],
	  double penalty,
	  int n_unique_indices,
	  int unique_indices[sumT],
	  int counter[P][sumT+1],
	  double sumstat[P][3][sumT+1],
	  double (*cost_function_vla[P])(),
	  // modify
	  double lastchangelik[n_unique_indices+1],
	  int* in_ncpts,
	  int* in_cpts)
	  // need to pass changepoint locations
	  // need to update lastchangelik
{
  // calculate the cost with no msr changepoints
  double cost_nochange = 0;
  for( int p=0; p<P; p++ )
    {

      cost_nochange += cost_function_vla[p](P,
					    sumT+1,
					    sumstat,
					    p,
					    1,
					    n_unique_indices,
					    counter[p][n_unique_indices]);
    }

  // calculate the cost with one msr changepoint
  /* 0 if a likelihood cannot be calculated prior to (inc) the proposed msr changepoint */
  int l_feas;
  /* 0 if a likelihood cannot be calculated after the proposed msr changepoint */
  int r_feas;
  /* number of observations up to the proposed msr changepoint */
  int l_count;
  /* number of observations after the proposed msr changepoint */
  int r_count;
  /* iterators */
  int p;
  int i;

  /*keep track of numbe of feasible msr changepoint locations found*/
  int nfeas = 0;
  /* store the likelihoods for each proposed msr changepoint */
  double liks[n_unique_indices];
  /*store the feasible msr changepoint location indices*/
  int msrcpt_index[sumT];
  for(i=1; i<n_unique_indices+1; i++)
    {
      liks[nfeas] = 0;
      l_feas = 0;
      r_feas = 0;

      for(p=0; p<P; p++)
	{
	  l_count = counter[p][i];
	  r_count = counter[p][n_unique_indices] - l_count;

	  if( l_count >= minseglen[p] )
	    {
	      liks[nfeas] += cost_function_vla[p](P,
						  sumT+1,
						  sumstat,
						  p,
						  1,
						  i,
						  l_count);
	      l_feas += 1;
	    }
	  if( r_count >= minseglen[p] )
	    {
	      liks[nfeas] += cost_function_vla[p](P,
						  sumT+1,
						  sumstat,
						  p,
						  i+1,
						  n_unique_indices,
						  r_count);
	      r_feas += 1;
	    }
	}
      if( (l_feas < 1) || (r_feas < 1) )
	{
	  1+1;
	}
      else
	{
	  msrcpt_index[nfeas] = i-1; // as sumstat has 0 pad
	  nfeas += 1;
	}
    }

  int idmin = argmin_double(nfeas, liks);
  // return most likely msr cpt location
  *(in_cpts) = msrcpt_index[idmin]+1;
  *(in_cpts+1) = n_unique_indices; // as C index from 0

  // loglig null
  lastchangelik[0] = cost_nochange;
  // loglik alt
  lastchangelik[1] = liks[idmin];
  // lrts
  lastchangelik[2] = lastchangelik[0] - lastchangelik[1];


  if( lastchangelik[0] - lastchangelik[1] > penalty )
    {
      // test significant
      *(in_ncpts) = 2;
    }else
    {
      // test not significant
      *(in_ncpts) = 1;
    }

}

void Call(
	  int *P, // number of sequences
	  int *T, // array of sequence lengths
	  int *sumT, // total number of observations
	  int *maxT,   // length of longets sequence

	  int *index, // stacked sequence indices
	  double *values, // stacked sequence values

	  int *minseglen, // pointer to array of minimum segment lengths
	  double *beta, // pointer to array of penalties
	  char **costname,// costname

	  int *in_nunique, // number of unique indices (to calc)
	  int *in_unique_index, // unique indices (to calc)
	  int *in_ncpts, // number of changepoints (to calc)
	  int *in_cpts, // pointer to array of changepoint locations
	  double *in_lastchangelik, // maximum likelihood (to calc)
	  char **method // method
	  )
{

  // convert to VLA
  int vla_index[*P][*maxT];
  double vla_values[*P][*maxT];
  double (*cost_function_vla[*P])();

  int j=0;
  for( int p=0; p<*P; p++ )
    {

      // assign index and values
      for( int t=0; t<*(T+p); t++ )
	{
	  vla_index[p][t] = *(index + j);
	  vla_values[p][t] = *(values + j);
	  j++;
	}

      // assign cost functions
      if( strcmp( *(costname + p), "normal_meanvar")==0 )
	{
	  *(cost_function_vla + p) = &normal_meanvar;
	} else if( strcmp( *(costname +p), "poisson_meanvar")==0 )
	{
	  *(cost_function_vla + p) = &poisson_meanvar;
	}
    }

  int counter[*P][*sumT+1];
  double sumstat[*P][3][*sumT+1];
  Sumstat_Count(*P,
		*maxT,
		*sumT,
		T,
		vla_index,
		vla_values,
		// to update...
		in_nunique,
		in_unique_index,
		counter,
		sumstat);

  int lastchange[*in_nunique+1];
  initialize_int0(*in_nunique+1, lastchange);

  if( strcmp(*method, "OP") == 0 )
    {
      // call OP
      OP_MF(*P,
	    *sumT,
	    minseglen,
	    beta,
	    sum_double(*P, beta),
	    *in_nunique,
	    counter,
	    sumstat,
	    cost_function_vla,
	    lastchange,
	    in_lastchangelik);

      // update changepoint locations
      get_cpts(*in_nunique,
	       in_cpts,
	       in_ncpts,
	       lastchange);
    } else if( strcmp(*method, "AMOC") == 0 )
    {
      // call AMOC
      AMOC(*P,
	   *sumT,
	   minseglen,
	   sum_double(*P, beta),
	   *in_nunique,
	   in_unique_index,
	   counter,
	   sumstat,
	   cost_function_vla,
	   // modify
	   in_lastchangelik,
	   in_ncpts,
	   in_cpts);
	}
}
