double normal_meanvar(int N,
		      int len,
		      double sumstat[N][3][len],
		      int n,
		      int s,
		      int e,
		      int seglen);

double poisson_meanvar(int N,
		       int len,
		       double sumstat[N][3][len],
		       int n,
		       int s,
		       int e,
		       int seglen);
