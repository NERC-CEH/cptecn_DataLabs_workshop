#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double normal_meanvar(int N,
		      int length,
		      double sumstat[N][3][length],
		      int n,
		      int s,
		      int e,
		      int seglen)
/*
  -2*loglik when statistics assumed to follow a Normal distribution with unknown mean and variance

  N:       number of data sequences
  length:  number of unique observations
  sumstat: 3-d dimensional array with counter values
  n:       data sequence
  s:       start index of segment
  e:       end index of segment
  seglen:  length of segment
*/
{
  double sigmaSq;
  double s1 = sumstat[n][1][e] - sumstat[n][1][s-1];
  double s2 = sumstat[n][2][e] - sumstat[n][2][s-1];

  sigmaSq = ( s2 - (s1*s1)/seglen )/( seglen );

  if( sigmaSq <= 0 )
    {
      sigmaSq = 0.00000000001;
    }

  return( (log(2*M_PI) + log(sigmaSq) + 1)*seglen );
}

double poisson_meanvar(int N,
		       int length,
		       double sumstat[N][3][length],
		       int n,
		       int s,
		       int e,
		       int seglen)
/*
  -2*loglik when statistics assumed to follow a Poisson distribution

  N:       number of data sequences
  length:  number of unique observations
  sumstat: 3-d dimensional array with counter values
  n:       data sequence
  s:       start index of segment
  e:       end index of segment
  seglen:  length of segment
*/
{
  double s1 = sumstat[n][1][e] - sumstat[n][1][s-1];

  if( s1 == 0 )
    {
      return( 0. );
    }

  return( 2*s1*(log(seglen)-log(s1)) );
}
