#' A synthetic dataset in list format
#'
#' "list" of length 3. Each list entry is a two column dataframe. Each dataframe contains data for one sequence.
#'
#' @author Aaron Paul Lowther \email{a.lowther1@lancaster.ac.uk}
"liData"

#' A synthetic dataset in dataframe format
#'
#' 7928 x 3 "tibble::tibble()"
#'
#' @format A dataset for three sequences each containing changes in mean.
#' \describe{
#'   \item{value}{sequence values}
#'   \item{index}{time index of value}
#'   \item{iid}{column specifying name of sequences}
#' }
#'
#' @author Aaron Lowther \email{a.lowther1@lancaster.ac.uk}
"dfData"
