#' An S4 class for cpt.msr output when 'method="OP"'
#'
#' @slot time_called Time called.
#' @slot time_complete Time complete.
#' @slot data "tibble::tibble()". Data that was analysed.
#' @slot summary "tibble::tibble()". Options provided in call to "cpt.msr()".
#' @slot params "tibble::tibble()". Parameters corresponding to "test.stat" entries for each segment.
#' @slot msr.cpts vector. Optimal mixed sampling rate changepoint locations for the penalty supplied.
#' @slot cpts "tibble::tibble()". Optimal changepoint locations derived from msr.cpts.
#' @slot window vector. Observation window for the data.
#' @slot lastchangelik dataframe. Cost (-2*loglikelihood) of the optimal segmentation up to that observation.
#'
#' @export
setClass(
    "cpt.msr",
    slots = list(
        time_called   = "POSIXt",
        time_complete = "POSIXt",
        data          = "data.frame",
        summary       = "data.frame",
        params        = "data.frame",
        msr.cpts      = "data.frame",
        cpts          = "data.frame",
        window        = "Date",
        lastchangelik = "data.frame"
    )
)

#' An S4 class for cpt.msr when 'method="AMOC"'
#'
#' @slot time_called Time called.
#' @slot time_complete Time complete.
#' @slot data "tibble::tibble()". Data that was analysed.
#' @slot unique_index vector. Ordered union of observed time indices.
#' @slot summary "tibble::tibble()". Options provided in call to "cpt.msr()".
#' @slot params "tibble::tibble()". Parameters corresponding to "test.stat" entries for each segment. 
#' @slot msr.cpt Date. Most likely msr changepoint location.
#' @slot cpt "tibble::tibble()". Most likely changepoint locations derived from msr.cpts.
#' @slot window vector. Observation window for the data.
#' @slot lik_null -2*log-likelihood under the null hypothesis.
#' @slot lik_alt -2*log-likelihood under the alternative hypothesis.
#' @slot lrts Likelihood ratio test statistic.
#' @slot test_signif Logical. Does lrts exceed exceed "sum(params$penalty)"?
#'
#' @export
setClass(
    "cpt.msr.test",
    slots = list(
        time_called = "POSIXt",
        time_complete = "POSIXt",
        data = "data.frame",
        unique_index = "Date",
        summary = "data.frame",
        params = "data.frame",
        msr.cpt = "data.frame",
        cpt = "data.frame",
        window = "Date",
        lik_null = "numeric",
        lik_alt = "numeric",
        lrts = "numeric",
        test_signif = "logical"
    )
)

#' An S4 method for cpt.msr
#'
#' @param x an object of type cpt.msr
#'
#' @importFrom rlang .data
#' 
#' @export
setMethod(
    "plot",
    "cpt.msr",
    function(x)
    {
        ## needed to avoid "No visible binding for global variables"
        index <- value <- loc <- id <- NULL

        ## facet labels
        facet.labs         <- x@summary$key
        names(facet.labs)  <- x@summary$id     

        ## plot of data
        out.plot <- 
            ggplot2::ggplot(
                         data = x@data,
                         ggplot2::aes(x = index, y = value)
                     ) +
            ggplot2::geom_line() +
            ## msr changepoints
            ggplot2::geom_vline(
                         data = x@msr.cpts,
                         ggplot2::aes(xintercept = loc),
                         colour = "#ff7f0e"
                     ) +
            ## changepoints
            ggplot2::geom_vline(
                         data = x@cpts,
                         ggplot2::aes(xintercept = loc),
                         colour = "#1f77b4",
                         linetype = 2
                     ) +
            ggplot2::facet_grid(
                         row = ggplot2::vars(id),
                         labeller = ggplot2::labeller(id = facet.labs)
                     )

        ## add segment means if they were estimated and calculated
        if( "mean" %in% x@params$type )
        {

            lagloc <- NULL
            
            ## table of indices 1 day before first index
            tbl.prefirstindex <- 
                x@data %>%
                dplyr::group_by(id) %>%
                dplyr::summarize(
                    loc = min(.data$index) - lubridate::days(1),
                    m = 0
                ) %>%
                dplyr::ungroup()

            ## table of mean value for start and end segment
            tbl.segmeans <- 
                x@params %>%
                dplyr::filter( .data$type == "mean" ) %>%
                dplyr::left_join(
                           x@cpts,
                           by = c("id", "m")
                       ) %>%
                dplyr::full_join(
                           tbl.prefirstindex,
                           by = c("id", "m", "loc")
                       ) %>%
                dplyr::group_by(.data$id) %>%
                dplyr::arrange_at("loc") %>%
                dplyr::mutate(lagloc = dplyr::lag(.data$loc)) %>%
                dplyr::ungroup() %>%
                dplyr::filter( !is.na(.data$lagloc) )

            return(
                out.plot +
                ggplot2::geom_segment(
                             data = tbl.segmeans,
                             ggplot2::aes(x = lagloc, xend = loc, y = value, yend = value),
                             colour = "#d62728"
                         )
                
            )
        }

        return( out.plot )
    }
)
