## source("R/call.R")
## load("data/data_df.RData")
## library(dplyr)
## print( head(data_df) )
## cpt.mf(
##     data_df,
##     rep("normal_meanvar", 3),
##     rep("bic", 3),
##     keys = c("daily", "monthly", "yearly"),
##     key_column = "iid"
## )
