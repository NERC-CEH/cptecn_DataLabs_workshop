check_Args <- function(data,
                       costs,
                       penalties,
                       minseglens,
                       key_value,
                       key_index,
                       keys,
                       key_column)
{
    ## costs check
    if( !all(costs %in% c("normal_meanvar", "normal_var", "poisson_meanvar")) )
    {
        stop(
            "only the following cost supported: ",
            "meanvar_normal ",
            "meanvar_poisson"
        )
    }

    ## penalties check
    if( !is.numeric(penalties) )
    {
        if( !all(penalties %in% c("aic", "bic")) )
        {
            stop(
                "only the following penalties supported: ",
                "normal_meanvar ",
                "normal_var ",
                "poisson_meanvar"
            )
        }
    }

    ##  formatted data that will be returned
    out <- list()

    if( "list" %in% class(data) )
    {
        if( is.null(keys) )
        {
            P <- length(data)
            keys <- 1:P
        }
        else
        {
            data <- data[keys]
        }

        for(p in 1:P)
        {
            ## extract data and sort by index
            out[[p]] <-
                tibble::tibble(
                            index = dplyr::pull(data[[p]], key_index),
                            value = dplyr::pull(data[[p]], key_value),
                            id = p,
                            key = keys[p]
                        ) %>%
                dplyr::arrange_at('index')
        }
    } else if( "data.frame" %in% class(data) )
    {
        if( is.null(keys) )
        {
            keys <- unique(dplyr::pull(data, key_column))
            warning(
                "keys not supplied: ",
                "penalties and costs may not be applied in desired order ",
                "check 'params' slot"
            )
        }

        P <- length(keys)

        for(p in 1:P)
        {
            ## extract sequence data from dataframe
            logic <- data[,key_column] == keys[p]

            ## sort by index
            out[[p]] <-
                tibble::tibble(
                            index = dplyr::pull(data[logic,], key_index),
                            value = dplyr::pull(data[logic,], key_value),
                            id = p,
                            key = keys[p]
                        ) %>%
                dplyr::arrange_at('index')
        }
    } else
    {
        stop("data must be list or data.frame")
    }

    if( length(costs) != length(keys) )
    {
        stop(
            length(costs),
            " test.stat supplied but using ",
            length(keys),
            " keys"
        )
    }
    if( length(penalties) != length(keys) )
    {
        stop(
            length(penalties),
            " penalties supplied but using ",
            length(keys),
            " keys"
        )
    }

    return(out)
}

get.model_parameters <-
    function(tbl.params,
             indata,
             tbl.summary,
             tbl.cpts)
{

    ## loop over all sequences
    for( i_id in tbl.summary$id )
    {
        ## select the data for this sequence
        tmp_data <- indata[[i_id]]

        ## define a small date to get first segment
        date.0 <- min(tmp_data$index) - lubridate::days(1)

        ## extract the summary statistic used for this sequence
        sum.stat <- tbl.summary[tbl.summary$id == i_id, ]$cost

        ## extract the changepoints for this sequence
        tmp_cpts <- sort(
            c(
                date.0,
                tbl.cpts[tbl.cpts$id == i_id,]$loc
            )
        )

        ## loop over all segments
        for( m in 2:length(tmp_cpts) )
        {
            ## select data for this segment
            seg.values <- tmp_data[
                tmp_data$index > tmp_cpts[m-1] & tmp_data$index <= tmp_cpts[m],
                ]$value

            ## length of segment
            seglen <- length(seg.values)

            ## summary statistics
            s1 <- sum(seg.values)
            s2 <- sum(seg.values**2)

            ## append parameters
            if( sum.stat %in% c("normal_meanvar") )
            {
                ## mean and variance
                df <- data.frame(
                    id    = i_id,
                    m     = m-1,
                    type  = c("mean", "variance"),
                    value = c(s1/seglen, ( s2 - (s1*s1)/seglen )/( seglen ))
                )
                
                tbl.params <- dplyr::full_join(
                                         df,
                                         tbl.params,
                                         by = c("id", "m", "value", "type")
                                     )
            }else if( sum.stat %in% c("normal_var") )
            {
                sigmaSq = ( s2 - (s1*s1)/seglen )/( seglen )

                ## variance
                df <- data.frame(
                    id    = i_id,
                    m     = m-1,
                    type  = "var",
                    value = sigmaSq
                )
                
                tbl.params <- dplyr::full_join(
                                         df,
                                         tbl.params,
                                         by = c("id", "m", "value", "type")
                                     )
            }else if( sum.stat %in% c("normal_poisson") )
            {
                ## mean
                df <- data.frame(
                    id    = i_id,
                    m     = m-1,
                    type  = "mean",
                    value = s1/seglen
                )
                
                tbl.params <- dplyr::full_join(
                                         df,
                                         tbl.params,
                                         by = c("id", "m", "value", "type")
                                     )
            }else
            {
                stop("sum.stat: ", sum.stat, " not supported in get.model_parameters")
            }
        }
    }   
    
    return(
        tbl.params %>%
        dplyr::arrange_at(c("id", "type", "m"))
    )
}

#' determine changepoint from msr changepoints
#'
#' @param msr.cpts vector. MSR changepoints
#' @param data list. Formatted data
#'
#' @export
map_changepoints <- function(msr.cpts, data)
{
    P <- length(data)
    out <- list()

    tmp_out <- msr.cpts
    for( p in 1:P )
    {
        M <- 0
        for( cpt in msr.cpts )
        {
            tmp_index <- dplyr::pull(data[[p]], "index")
            logic <- tmp_index <= cpt

            if( sum(logic) > 0)
            {
                M <- M+1
                tmp_out[M] <- max(tmp_index[logic])
            }
        }

        if(M > 0)
        {
            out[[p]] <- sort(unique(tmp_out[1:M]))
        }else
        {
            out[[p]] <- NA#NULL
        }
    }

    return(
        tibble::tibble(
                    loc = do.call(c, out),
                    id = do.call(
                        c,
                        mapply(
                            rep,
                            as.list(1:P),
                            lapply(out, length), SIMPLIFY=FALSE
                        )
                    ),
                    m = do.call(c, lapply(out, function(x){return(1:length(x))}))
                )
    )
    return(out)
}


summary_tbl <- function(data, costs, keys, penalties, minseglens)
{
    P <- length(data)
    if( is.null(keys) )
    {
        keys <- 1:P
    }

    ## number of parameters for cost
    npars <- c("normal_meanvar" = 3, "normal_var" = 2, "poisson_meanvar" = 2)

    ## minimum segment length for cost
    msl <- c("normal_meanvar" = 2, "normal_var" = 2, "poisson_meanvar" = 1)

    ## initialise table
    params <- tibble::tibble(
                          T = do.call(c, lapply(data, nrow)),
                          cost = costs,
                          k = npars[costs],
                          logT = log(T),
                          key = keys,
                          id = 1:P
                      )

    if( !is.numeric(penalties) )
    {
        params[,'penalty'] <- 2*params$k*(penalties == "aic") +
            params$k*params$logT*(penalties == "bic")
        params[,'penname'] <- penalties
    }else
    {
        params[,'penname'] <- rep("user_defined", P)
        params[,'penalty'] <- penalties
    }
    if( is.null(minseglens) )
    {
        params[,'minseglen'] <- msl[costs]
    }else
    {
        params[,'minseglen'] <- minseglens
    }

    return( params )
}
