double normal_meanvar(int N,
		      int len,
		      double sumstat[N][3][len],
		      int n,
		      int s,
		      int e,
		      int seglen);

double normal_var(int P,
		  int length,
		  double sumstat[P][3][length],
		  int p,
		  int s,
		  int e,
		  int seglen);

double poisson_meanvar(int N,
		       int len,
		       double sumstat[N][3][len],
		       int n,
		       int s,
		       int e,
		       int seglen);
