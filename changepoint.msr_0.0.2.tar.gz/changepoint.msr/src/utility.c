#include <stdio.h>
#include <stdlib.h>

int argmin_double(size_t N, double x[N])
{
  int argmin = 0;
  double min = x[0];

  for(size_t n=1; n<N; n++)
    {
      if( x[n] < min )
	{
	  min = x[n];
	  argmin = n;
	}
    }

  return argmin;
}

int argmin_int(size_t N, int x[N])
{
  int argmin = 0;
  int min = x[0];

  for(size_t n=1; n<N; n++)
    {
      if( x[n] < min )
	{
	  min = x[n];
	  argmin = n;
	}
    }

  return argmin;
}

void initialize_double0(size_t N, double x[N])
/*
  initialise all values of double VLA to 0
*/
{
  for(size_t n=0; n<N; n++){ x[n] = 0; }
}

void initialize_int0(size_t N, int x[N])
/*
  initialise all values of int VLA to 0
*/
{
  for(size_t n=0; n<N; n++){ x[n] = 0; }
}

int max_int(size_t N, int x[N])
{
  int max = x[0];

  for(size_t n=1; n<N; n++)
    {
      if( x[n] > max )
	{
	  max = x[n];
	}
    }

  return max;
}

double sum_double(size_t N, double x[N])
{
  double sum = 0;

  for(size_t n=0; n<N; n++)
    {
      sum += x[n];
    }

  return sum;
}

int sum_int(size_t N, int x[N])
{
  int sum = 0;

  for(size_t n=0; n<N; n++){ sum += x[n]; }

  return sum;
}
