int argmin_double(size_t N, double x[N]);

int argmin_int(size_t N, int x[N]);

void initialize_double0(size_t N, double x[N]);

void initialize_int0(size_t N, int x[N]);

int max_int(size_t N, int x[N]);

double sum_double(size_t N, double x[N]);

int sum_int(size_t N, int x[N]);
